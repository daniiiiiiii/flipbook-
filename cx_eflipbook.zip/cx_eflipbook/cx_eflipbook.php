<?php 

/*
   Plugin Name: Cx Flipbook Elementor
   Description: Flipbook by cipherox
   Version: 1.2
   Author: cipherox
   Author URI: https://cipherox.com/
   License: MIT
*/


define( "CX_Flipbook_plugin_uri" , plugins_url("",__FILE__) );

add_action("wp_enqueue_scripts", "cx_regiester_wp_enqueue_script" );
function cx_regiester_wp_enqueue_script() {
	
	wp_enqueue_script( 'jquery', 'https://code.jquery.com/jquery-2.2.4.min.js');

	wp_enqueue_script( 'modernizr.custom.js', CX_Flipbook_plugin_uri .  '/js/modernizr.custom.js');

	wp_enqueue_script( 'jquery.bookblock', CX_Flipbook_plugin_uri .  '/js/jquery.bookblock.min.js');
	
	wp_enqueue_script( 'cx.flipbook.bookblock', CX_Flipbook_plugin_uri .  '/js/custom.js');
	wp_enqueue_style(  'jquery.bookblock', CX_Flipbook_plugin_uri .  '/css/bookblock.css' );


}



add_action("elementor/widgets/widgets_registered", "cx_regiester_Elementor_Flipbook_Widget" );

function cx_regiester_Elementor_Flipbook_Widget( $widgets_manager ) {

	

	if ( class_exists("\Elementor\Widget_Base") && !class_exists("Elementor_Flipbook_Widget")) {

		class Elementor_Flipbook_Widget extends \Elementor\Widget_Base {

			private $cx_component_name = 'Flipbook';
			private $cx_namespace = 'cx_eflipbook';
			private $total_page = 10;

			public function get_name() { return sanitize_title( $this->cx_component_name ) ;}

			public function get_title() { return __( $this->cx_component_name, $this->cx_namespace ) ; }

			public function get_icon() {return 'fa fa-code';}

			public function get_categories() { return [ 'general' ]; }

			protected function _register_controls() {

				$this->start_controls_section( 'settings', [

					'label' => __( 'settings ', $this->cx_namespace ),
					'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
				]);
				
				$this->add_control( 'nav_container', [

					'label' => __( 'nav container', $this->cx_namespace ),

				]);
				$this->add_control( 'height', [

					'label' => __( 'height', $this->cx_namespace ),
					
				]);

				$this->end_controls_section();

				$posts = get_posts([
					"post_type"=>"elementor_library",
					"numberpost"=>-1,
				]);
				$opt = [
					0 => '',
				];
				foreach ($posts as $p) {
					$opt[ $p->ID ] = $p->post_title;
				}
				
				for ($i=1; $i <= $this->total_page; $i++) { 
				 	$this->start_controls_section( 'page_section_' . $i, [
							'label' => __( 'Page ' . $i, $this->cx_namespace ),
							'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
						]
					);
					$this->add_control( 'label_' . $i, [
							'label' => __( 'label ' . $i, $this->cx_namespace ),							
						]
					);
				 	$this->add_control( 'post_' . $i, [
							'label' => __( 'Template ' . $i, $this->cx_namespace ),
							'type' => \Elementor\Controls_Manager::SELECT,
							'default' => 'solid',
							'options' => $opt,
						]
					);
					$this->end_controls_section();
				} 
				

				
			}

			protected function render() {
				$list = [];
				for ($i=1; $i <= $this->total_page; $i++) { 

					$label = $this->get_settings( 'label_' . $i );
					$page_section = $this->get_settings( 'post_' . $i );
					
					
					if (  strlen($label) && $page_section ) {
						
						$list[] = [
							"label"		=> $label,
							"content"	=> $page_section,
						];	
					}

				}

				
				$index = 1;
				$nav_container = $this->get_settings( 'nav_container' );
				$nav_container = trim($nav_container);

				?><div class="cx-bb-bookblock" data-nav_target='<?= $nav_container ?>' ><?php 

					if ( !strlen($nav_container) ) {

						?><div class='cx-bb-bookblock-header'><?php 
							?><ul class="bb-bookblock-header-ul"><?php 
								foreach ($list as $c) {

									?><li ><?= $c['label'] ?></li><?php 

								}
							?></ul><?php 
						?></div><?php 
					}

					?><div id="bb-bookblock" class="bb-bookblock" ><?php 

						foreach ($list as $c) {

							?><div data-label='<?=  $c['label'] ?>' id="<?= sanitize_title( $c['label'] ) ?>" class="sectioncontainer bb-item sectionno-<?= $index ?>"><?php

								echo do_shortcode( '[elementor-template id="' . $c['content'] . '"]');

							?></div><?php 
							
							$index++;

						}
					?></div><?php 
				?></div><?php 

			}

			protected function _content_template() {}

		}
		$widgets_manager->register_widget_type( new Elementor_Flipbook_Widget() );
		
	}

}