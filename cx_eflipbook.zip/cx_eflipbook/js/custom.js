(function($) {
	$(function() {
		$( '.cx-bb-bookblock' ).each(function(k,v) {

			if ( !$(v).hasClass("bookblock-init") ) {

				var bookblock = $(v).find('#bb-bookblock').bookblock({

					speed : 800,
					perspective : 2000,
					shadowSides	: 0.8,
					shadowFlip	: 0.4,

				});
				nav_str = $(v).attr("data-nav_target");
				var nav = null;
				
				if ( typeof nav_str != "undefined" && nav_str.length &&  $(nav_str).length ) {
					nav = $(nav_str);
					nav.append('<ul class="bb-bookblock-header-ul"></ul>');
					

					$(v).find('#bb-bookblock .bb-item ').each(function(kkk,vvv) {
						nav.find("ul").append( $(vvv).attr("data-label") );
					});

				} else {
					nav = $(v).find('.cx-bb-bookblock-header')
				}

				$(v).find('#bb-bookblock').addClass('bb-vertical');


				nav.find('li').click(function() {

					nav.find('li').removeClass('active-elem')
					$(this).addClass('active-elem')
					
					bookblock.jump( $(this).index() + 1 );

				});

				$(v).addClass("bookblock-init");
				nav.find('li').first().trigger("click");
				
			}
					
		})
		
	})
	
})(jQuery)